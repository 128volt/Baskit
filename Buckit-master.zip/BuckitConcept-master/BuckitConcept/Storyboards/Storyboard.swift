//
//  Storyboard.swift
//  BuckitConcept
//
//  Created by Vasily Ulianov on 29.01.17.
//  Copyright © 2017 Wallace Neel. All rights reserved.
//

import UIKit

struct Storyboard {
	static var changeList: UIStoryboard { return UIStoryboard(name: "ChangeList", bundle: nil) }
}
